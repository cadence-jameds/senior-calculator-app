package com.jameds.seniorcalculator;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private TextView display;
    private TextView statusText;
    private TextToSpeech tts;

    private String currentInput = "0";
    private BigDecimal storedValue = null;
    private String pendingOperator = null;
    private boolean startNewNumber = false;
    private boolean justCalculated = false;

    private static final int MAX_INPUT_LENGTH = 18;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        statusText = findViewById(R.id.statusText);

        tts = new TextToSpeech(this, this);

        bindNumberButton(R.id.btn0, "0");
        bindNumberButton(R.id.btn1, "1");
        bindNumberButton(R.id.btn2, "2");
        bindNumberButton(R.id.btn3, "3");
        bindNumberButton(R.id.btn4, "4");
        bindNumberButton(R.id.btn5, "5");
        bindNumberButton(R.id.btn6, "6");
        bindNumberButton(R.id.btn7, "7");
        bindNumberButton(R.id.btn8, "8");
        bindNumberButton(R.id.btn9, "9");

        findViewById(R.id.btnDot).setOnClickListener(v -> onDecimalPoint());
        findViewById(R.id.btnAdd).setOnClickListener(v -> onOperator("+"));
        findViewById(R.id.btnSubtract).setOnClickListener(v -> onOperator("-"));
        findViewById(R.id.btnMultiply).setOnClickListener(v -> onOperator("*"));
        findViewById(R.id.btnDivide).setOnClickListener(v -> onOperator("/"));
        findViewById(R.id.btnEquals).setOnClickListener(v -> onEquals());
        findViewById(R.id.btnAc).setOnClickListener(v -> clearAll());
        findViewById(R.id.btnBack).setOnClickListener(v -> backspace());
        findViewById(R.id.btnSpeak).setOnClickListener(v -> speakCurrentValue());

        updateDisplay();
    }

    private void bindNumberButton(int id, String number) {
        Button button = findViewById(id);
        button.setOnClickListener(v -> {
            onDigit(number);
            speak(number);
        });
    }

    private void onDigit(String digit) {
        if (startNewNumber || justCalculated) {
            currentInput = digit;
            startNewNumber = false;
            justCalculated = false;
        } else if ("0".equals(currentInput)) {
            currentInput = digit;
        } else if (currentInput.length() < MAX_INPUT_LENGTH) {
            currentInput += digit;
        }
        updateDisplay();
    }

    private void onDecimalPoint() {
        if (startNewNumber || justCalculated) {
            currentInput = "0.";
            startNewNumber = false;
            justCalculated = false;
        } else if (!currentInput.contains(".") && currentInput.length() < MAX_INPUT_LENGTH) {
            currentInput += ".";
        }
        updateDisplay();
        speak("小數點");
    }

    private void onOperator(String operator) {
        try {
            BigDecimal currentValue = parseCurrent();

            if (storedValue == null) {
                storedValue = currentValue;
            } else if (pendingOperator != null && !startNewNumber) {
                BigDecimal result = calculate(storedValue, currentValue, pendingOperator);
                if (result == null) {
                    return;
                }
                storedValue = result;
                currentInput = format(result);
            }

            pendingOperator = operator;
            startNewNumber = true;
            justCalculated = false;
            updateDisplay();
            speak(operatorToSpeech(operator));
        } catch (Exception e) {
            showError("輸入錯誤");
        }
    }

    private void onEquals() {
        if (storedValue == null || pendingOperator == null || startNewNumber) {
            speakCurrentValue();
            return;
        }

        try {
            BigDecimal currentValue = parseCurrent();
            BigDecimal result = calculate(storedValue, currentValue, pendingOperator);
            if (result == null) {
                return;
            }

            currentInput = format(result);
            storedValue = null;
            pendingOperator = null;
            startNewNumber = false;
            justCalculated = true;
            updateDisplay();

            speak("答案是 " + numberForSpeech(currentInput));
        } catch (Exception e) {
            showError("計算錯誤");
        }
    }

    private BigDecimal calculate(BigDecimal left, BigDecimal right, String operator) {
        try {
            switch (operator) {
                case "+":
                    return left.add(right);
                case "-":
                    return left.subtract(right);
                case "*":
                    return left.multiply(right);
                case "/":
                    if (right.compareTo(BigDecimal.ZERO) == 0) {
                        showError("不能除以零");
                        speak("不能除以零");
                        return null;
                    }
                    return left.divide(right, MathContext.DECIMAL64);
                default:
                    return right;
            }
        } catch (ArithmeticException e) {
            showError("數字太大");
            return null;
        }
    }

    private void clearAll() {
        currentInput = "0";
        storedValue = null;
        pendingOperator = null;
        startNewNumber = false;
        justCalculated = false;
        statusText.setText("大字語音計算機");
        updateDisplay();
        speak("清除");
    }

    private void backspace() {
        if (startNewNumber || justCalculated) {
            return;
        }

        if (currentInput.length() > 1) {
            currentInput = currentInput.substring(0, currentInput.length() - 1);
            if ("-".equals(currentInput)) {
                currentInput = "0";
            }
        } else {
            currentInput = "0";
        }

        updateDisplay();
        speak("退格");
    }

    private BigDecimal parseCurrent() {
        if (currentInput.endsWith(".")) {
            return new BigDecimal(currentInput.substring(0, currentInput.length() - 1));
        }
        return new BigDecimal(currentInput);
    }

    private String format(BigDecimal value) {
        BigDecimal normalized = value.stripTrailingZeros();
        String text = normalized.toPlainString();

        if (text.length() > 20) {
            text = normalized.round(MathContext.DECIMAL64).toEngineeringString();
        }

        return text;
    }

    private void updateDisplay() {
        display.setText(currentInput);

        if (pendingOperator != null && storedValue != null) {
            statusText.setText("目前運算：" + operatorToVisible(pendingOperator));
        } else {
            statusText.setText("大字語音計算機");
        }

        int length = currentInput.length();
        if (length <= 9) {
            display.setTextSize(68);
        } else if (length <= 13) {
            display.setTextSize(54);
        } else {
            display.setTextSize(42);
        }
    }

    private String operatorToVisible(String op) {
        switch (op) {
            case "+": return "＋";
            case "-": return "－";
            case "*": return "×";
            case "/": return "÷";
            default: return op;
        }
    }

    private String operatorToSpeech(String op) {
        switch (op) {
            case "+": return "加";
            case "-": return "減";
            case "*": return "乘以";
            case "/": return "除以";
            default: return "";
        }
    }

    private void speakCurrentValue() {
        speak(numberForSpeech(currentInput));
    }

    private String numberForSpeech(String value) {
        return value.replace("-", "負")
                .replace(".", "點");
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        statusText.setText(message);
    }

    private void speak(String text) {
        if (tts == null) {
            return;
        }
        tts.stop();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "seniorCalculatorSpeech");
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && tts != null) {
            int result = tts.setLanguage(Locale.TRADITIONAL_CHINESE);
            tts.setSpeechRate(0.85f);
            tts.setPitch(1.0f);

            if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED) {
                statusText.setText("語音未安裝，計算仍可正常使用");
            } else {
                statusText.setText("大字語音計算機");
            }
        } else {
            statusText.setText("語音無法啟動，計算仍可正常使用");
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
