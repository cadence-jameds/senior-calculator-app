# 大字語音計算機 v1.0.0

正式版功能：

- 超大字、超大按鍵
- 直向 / 橫向兩套獨立自適應介面
- 橫向上方顯示結果、下方按鍵
- 四則運算：＋、－、×、÷
- AC、退格、小數點、＝
- 算式與答案分行顯示
- Android 原生繁體中文 TTS
- 語音預設關閉，可由按鈕開啟
- 完全離線
- 不宣告 INTERNET 權限
- 正式 App icon
- GitHub Actions 自動產生可安裝的 signed release APK

## 正式 APK

GitHub Actions 完成後，下載 Artifact：

`Senior-Calculator-v1.0.0`

解壓後得到：

`Senior-Calculator-v1.0.0.apk`

## 簽章說明

此專案內含固定簽章金鑰，方便家庭 / 私人裝置持續覆蓋更新。
若未來要上架 Google Play，建議另行建立私有正式 Play Store 簽章。
